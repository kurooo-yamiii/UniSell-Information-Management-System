﻿using WebUniform.Models;

namespace WebUniform.ViewModel
{
    public class DashboardViewModel
    {
        public List<Slack> Slacks { get; set; }
        public List<Uniform> Uniforms { get; set; }
    }
}
